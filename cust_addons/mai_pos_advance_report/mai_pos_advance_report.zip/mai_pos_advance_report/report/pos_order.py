from odoo import fields,models,api,_

class ResCompany(models.Model):
    _inherit = "res.company"

    report_header_tilte = fields.Char('Report Header Title')


class PrintCategoryMaiReport(models.AbstractModel):
    _name = 'report.mai_pos_advance_report.print_category_mai'
    _description = "Print Category Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'doc_model': 'pos.order',
            'lines': data.get('filter_data'),
            'company_id': self.env.user.company_id
        }


class PrintProductMaiReport(models.AbstractModel):
    _name = 'report.mai_pos_advance_report.print_product_mai'
    _description = "Print Product Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'doc_model': 'pos.order',
            'lines': data.get('filter_data'),
            'company_id': self.env.user.company_id
        }


class PrintProductStockMaiReport(models.AbstractModel):
    _name = 'report.mai_pos_advance_report.print_product_stock_mai'
    _description = "Print Product Stock Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        return {
            'doc_ids': docids,
            'doc_model': 'pos.order',
            'lines': data.get('filter_data'),
            'company_id': self.env.user.company_id
        }