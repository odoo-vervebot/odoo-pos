{
    "name": "POS Daily Sales Report - category wise sales, product wise sales, pos product wise stock ",
    "version": "15.1.1.1",
    "summary": """ POS daily sales Report
    - Product wise daily sales report
    - product category wise daily sales report
    - Product wise daily stock report
    - Print Report in PDF and Excel Report.
    - Easily to Understand Daily Sales Report
    """,
    'description':"POS Daily Sales Report - category wise sales, product wise sales, pos product wise stock ",
    "price": 16,
    'currency': 'EUR',
    "author" : "MAISOLUTIONSLLC",
    'sequence': 1,
    "email": 'apps@maisolutionsllc.com',
    "website":'http://maisolutionsllc.com/',
    'license': 'OPL-1',
    'category':"Point of Sale",
    "depends": [
        "point_of_sale",
    ],
    "data": [
        'security/ir.model.access.csv',
        'wizard/res_company_view.xml',
        'wizard/pos_order_category_report.xml',
        'report/pos_report_category_template.xml',
        'wizard/pos_order_product_report.xml',
        'report/pos_report_product_template.xml',
        'wizard/pos_order_product_stock_report.xml',
        'report/pos_report_product_stock_template.xml',
        'report/pos_order.xml',
    ],
    'qweb': [],
    'css': [],
    'js': [],
    'images': ['static/description/main_screenshot.png'],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
